$(function() {
  RenderLineChart("div1", "/index.char_ep_on_json_day");
  RenderLineChart("div2", "/index.char_ep_putdown_json_day");
  RenderLineChart("div3", "/index.char_selltosys_json_day");
  RenderLineChart("div4", "/index.char_ep_upgrade_json_day");
  RenderLineChart("div5", "/index.char_eq_recast_json_day");
  RenderLineChart("div6", "/index.char_eq_enchant_json_day");
  RenderLineChart("div7", "/index.char_openbox_json_day");
  RenderLineChart("div8", "/index.char_enchant_compose_json_day");
  });

