function checksubmit() {
    this.form1.submit();
}

$("#sub_btn").click(
    function(){
    checksubmit();
    }
);




